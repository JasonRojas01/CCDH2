<!-- menu.php -->
<nav class="col-md-2 d-none d-md-block sidebar py-3">
    <div class="position-sticky">
        <ul class="nav flex-column" id="dashboard-menu">

            <li class="nav-item">
                <a class="nav-link" href="administracionUsuario.php">
                    <span class="bi bi-house"></span> Dashboard Usuario
                </a>
            </li>

            
            <li class="nav-item">
                <a class="nav-link" href="crudAsesorias.php">
                    <span class="bi bi-people"></span> Servicios Solicitados
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="crudVoluntariado.php">
                    <span class="bi bi-people"></span> Voluntariado
                </a>
            </li>

        </ul>
    </div>
</nav>
